package testCases;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import baseClass.TestBase;
import pages.ChooseFlights;
import pages.ConfirmationPage;
import pages.HomePage;
import pages.PurchaseFlight;

public class TestCase1 extends TestBase {
	HomePage homePage;
	ChooseFlights chooseFlights;
	PurchaseFlight purchaseFlight;
	ConfirmationPage confirmationPage;
	
	public TestCase1() {
		super();
	}
	
	@BeforeClass
	public void setUp() {
		intialization();
		homePage = new HomePage();
		chooseFlights = new ChooseFlights();
		purchaseFlight = new PurchaseFlight();
		confirmationPage = new ConfirmationPage();
	}
	
	@Test(priority=1)
	public void loginPageTest() {
		String title = homePage.pageTitle();
		Assert.assertEquals(title, "BlazeDemo");
		homePage.selectDepaCity(prop.getProperty("DepartCity"));
		homePage.selectDestCity(prop.getProperty("DestinationCity"));
		homePage.clickFindFlights();
	}
	
	
	@Test(priority=2)
	public void chooseFligthTest() {
		String title = chooseFlights.ChooseFlightsTitle();
		Assert.assertEquals(title, "BlazeDemo - reserve");
		chooseFlights.validatePageText();
		chooseFlights.selectFlight();		
	}
		
	
	@Test(priority=3)
	public void purchaseFlightTest() {
		String title = purchaseFlight.purchaseFlightTitle();
		Assert.assertEquals(title, "BlazeDemo Purchase");
		purchaseFlight.enterName(prop.getProperty("name"));
		purchaseFlight.enterAddress(prop.getProperty("address"));
		purchaseFlight.enterCity("city");
		purchaseFlight.enterState("state");
		purchaseFlight.enterZipCode("zipcode");
		purchaseFlight.enterCardNumber("cardnum");
		purchaseFlight.enterCardMonth("cradmonth");
		purchaseFlight.enterCardYear("cardyear");
		purchaseFlight.enterCardName("cardname");
		purchaseFlight.enableRememberMeCheckBox();
		purchaseFlight.clickPurchaseFlights();		
	}
	
	@Test(priority=4)
	public void confirmationTest() {
		String title = confirmationPage.pageTitle();
		Assert.assertEquals(title, "BlazeDemo Confirmation");
		confirmationPage.validateBooking();				
	}
	
	@AfterClass
	public void complete() {
		driver.quit();
	}
	
	

}
