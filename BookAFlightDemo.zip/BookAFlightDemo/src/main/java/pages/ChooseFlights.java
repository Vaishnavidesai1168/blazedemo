package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import baseClass.TestBase;

public class ChooseFlights extends TestBase {

	@FindBy(xpath = "//h3[starts-with(text(),'Flights from')]")
	WebElement pageText;
	
	@FindBy(xpath = "//td[text()='United Airlines']/preceding-sibling::td[2]")
	WebElement chooseFlight;
	
	public ChooseFlights(){
        PageFactory.initElements(driver, this);
    }
	
	public String ChooseFlightsTitle() {
		return driver.getTitle();
	}
	
	public void validatePageText() {
		Assert.assertEquals(true, pageText.isDisplayed());
	}
	
	public void selectFlight() {
		chooseFlight.click();
	}

	
}
