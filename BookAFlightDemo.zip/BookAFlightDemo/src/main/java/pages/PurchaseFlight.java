package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import baseClass.TestBase;

public class PurchaseFlight extends TestBase{
	
	@FindBy(xpath = "//input[@placeholder='First Last']")
	WebElement name;
	
	@FindBy(xpath = "//input[@id='address']")
	WebElement address;
	
	@FindBy(xpath = "//input[@id='city']")
	WebElement city;
	
	@FindBy(xpath = "//input[@id='state']")
	WebElement state;
	
	@FindBy(xpath = "//input[@id='zipCode']")
	WebElement zipCode;
	
	@FindBy(xpath = "//select[@id='cardType']")
	WebElement cardType;
	
	@FindBy(xpath = "//input[@id='creditCardNumber']")
	WebElement creditCardNumber;
	
	@FindBy(xpath = "//input[@id='creditCardMonth']")
	WebElement month;
	
	@FindBy(xpath = "//input[@id='creditCardYear']")
	WebElement year;
	
	@FindBy(xpath = "//input[@id='nameOnCard']")
	WebElement nameOnCard;
	
	@FindBy(xpath = "//input[@id='rememberMe']")
	WebElement rememberMe;
	
	@FindBy(xpath = "//input[@value='Purchase Flight']")
	WebElement purchaseFlight;
	
	public String purchaseFlightTitle() {
		return driver.getTitle();
	}
	
	public PurchaseFlight(){
        PageFactory.initElements(driver, this);
    }


    public void enterName(String value){
    	name.sendKeys(value);
    }

    public void enterAddress(String value){
        address.sendKeys(value);
    }

    public void enterCity(String value){
        city.sendKeys(value);
    }

    public void enterState(String value){
        state.sendKeys(value);
    }

    public void enterZipCode(String value){
        zipCode.sendKeys(value);
    }

    public void selectCardType(String value){
        Select type = new Select(cardType);
        type.selectByValue(value);
    }

    public void enterCardNumber(String value){
    	creditCardNumber.sendKeys(value);
    }

    public void enterCardMonth(String value){
        month.sendKeys(value);
    }

    public void enterCardYear(String value){
        year.sendKeys(value);
    }

    public void enterCardName(String value){
    	nameOnCard.sendKeys(value);
    }

    public void enableRememberMeCheckBox(){
    	rememberMe.click();
    }
    
    public void clickPurchaseFlights(){
       purchaseFlight.click();
    }

}
