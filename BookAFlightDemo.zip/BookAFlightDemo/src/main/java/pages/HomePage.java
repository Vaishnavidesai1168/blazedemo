package pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import baseClass.TestBase;

public class HomePage extends TestBase {
	
	
	@FindBy(xpath = "//select[@name='fromPort']")
	WebElement departureCity;
	
	@FindBy(xpath = "//option[text()='Portland']")
	WebElement departure_City;
	
	
	@FindBy(xpath="//select[@name='toPort']")
	WebElement destinationCity;
	
	@FindBy(xpath="//option[text()='Berlin']")
	WebElement destination_City;
	
	@FindBy(xpath="//input[@value='Find Flights']")
	WebElement findFlights;
	
	public HomePage() {
		PageFactory.initElements(driver, this); 
	}
	
	public String pageTitle() {
		 return driver.getTitle(); 
	}
	
	public void selectDepaCity(String value) {		
		
//		Select depaCity = new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
//		depaCity.selectByVisibleText("Paris");
		departureCity.click();
		departure_City.click();
	}
	
	public void selectDestCity(String value) {
		destinationCity.click();
		destination_City.click();
//		Select destCity =new Select(destinationCity);
//		destCity.selectByValue(value);
	}
	
	public void clickFindFlights() {
		findFlights.click();
	}
    

}
